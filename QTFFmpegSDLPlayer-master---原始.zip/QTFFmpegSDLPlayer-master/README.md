# QTFFmpegSDLPlayer
使用ffmpeg做的播放器</br>
1，SDL处理音频，ffmpeg处理编解码音视频文件，qt做ui界面</br>
2，使用多线程双缓冲队列播放音视频</br>
3，使用视频追逐音频的策略实现音视频同步</br>
4，支持视频镜像操作，黑白彩色转换</br>
![Image text](https://github.com/huimingli/QTFFmpegSDLPlayer/blob/c5676c15c290099b6f5790b3f5f20fb73df4ee12/QQ%E5%9B%BE%E7%89%8720180223210613.png)
</br>
项目的主要结构</br>
![Image text](https://github.com/huimingli/QTFFmpegSDLPlayer/blob/master/20180223224324.png)
